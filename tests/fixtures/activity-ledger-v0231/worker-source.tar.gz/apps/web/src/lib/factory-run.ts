import { factoryWindow } from "./factory";
import {
	FACTORY_STREAMS,
	type FactoryRepo,
	type FactorySnapshot,
	type FactoryStreamName,
	type FactoryWindow,
} from "./factory-types";
import { REPO_SNAPSHOT_TABS, SITE_SNAPSHOT_KINDS } from "./snapshot-kinds";

export const RUN_COOLDOWN_MS = 60_000;
export const REPO_COOLDOWN_MS = 15 * 60_000;
export const RUN_LEASE_MS = 40_000;
export const RUN_MAX_RETRIES = 3;
export const FACTORY_REPO_CONCURRENCY = 4;
export type RunStatus = "running" | "paused" | "completed" | "partial" | "cancelled" | "failed";
export type StepStatus =
	| "pending"
	| "running"
	| "success"
	| "failed"
	| "skipped"
	| "unavailable"
	| "limited";
export type StepKind =
	| "inventory"
	| "restore"
	| "contributions"
	| "activity"
	| "activity-contributions"
	| "metadata"
	| FactoryStreamName
	| "commit"
	| "snapshot"
	| "publish";
export type FactoryRunStep = {
	kind: StepKind;
	sourceHead?: string | null;
	sourceBranch?: string | null;
	strategy?: "full" | "incremental" | "reused";
	resource?: string;
	snapshotCursor?: number;
	repo: string | null;
	status: StepStatus;
	attempts: number;
	retryFailures?: number;
	startedAt: string | null;
	finishedAt: string | null;
	durationMs: number;
	pages: number;
	error: string | null;
};
export type FactoryRun = {
	invocations?: number;
	atomicPublication?: true;
	publishedAt?: string | null;
	activityWindow?: import("./activity-types").ActivityWindow;
	previousActivityRunId?: string | null;
	activityContributions?: import("./activity-types").ActivityContributions;
	id: string;
	account_id: string;
	owner: string;
	requestKey: string;
	selection?: RunSelection;
	mode: "catalog" | "refresh";
	depth?: "quick" | "deep";
	trigger?: "manual" | "daily" | "weekly";
	schedule?: { kind: "daily" | "weekly" | "catalog"; dueAt: string };
	repos: string[];
	siteRepos?: string[];
	repoIds: Record<string, string>;
	window: FactoryWindow;
	steps: FactoryRunStep[];
	cursor: number;
	status: RunStatus;
	deadlineAt?: string;
	error?: string;
	missedSlots?: { firstDueAt: string; lastDueAt: string; count: number };
	startedAt: string;
	updatedAt: string;
	finishedAt: string | null;
	nextAttemptAt: string;
	requests: number;
	version: number;
	checkpoint: FactorySnapshot | null;
	restoreCursor: number;
};
export type RepoRefreshState = {
	dependencyLimit?: { reason_code: "dependency_parse_unsupported"; reason: string | null };
	attemptRunId?: string;
	attemptStatus?: string;
	observation?: FactoryRepo["observation"];
	repo: string;
	refreshedAt: string | null;
	status: "success" | "failed" | "partial";
	nextAllowedAt: string;
	attemptedAt?: string;
	durationMs?: number;
	retries?: number;
	error?: string | null;
	version?: string | null;
	coverage?: number;
};
export type RunFinishEstimateReason =
	| "terminal"
	| "no_completed_history"
	| "invalid_started_at"
	| "not_executed"
	| null;
export type FactoryRunView = Omit<FactoryRun, "checkpoint"> & {
	progress: ReturnType<typeof runProgress>;
	leaseUntil: string | null;
	expectedFinishAt: string | null;
	expectedFinishAtReason: RunFinishEstimateReason;
};
export type FactoryRunResponse = {
	storage?: { resourceBytes: number; totalBytes: number };
	account_id: string;
	serverNow: string;
	nextAllowedAt: string | null;
	current: FactoryRunView | null;
	history: FactoryRunView[];
	repositories: RepoRefreshState[];
	catalog: FactoryRepo[];
	catalogUpdatedAt: string | null;
	catalogComplete: boolean;
	publication: string | null;
};
export type RunSelection = {
	scope: "all" | "selected" | "filter" | "stale" | "failed";
	repos?: string[];
	order?: string[];
	repo?: string;
	language?: string;
	topic?: string;
	query?: string;
};
export function selectRunRepos(
	repos: FactoryRepo[],
	states: Pick<RepoRefreshState, "repo" | "refreshedAt" | "status" | "nextAllowedAt">[],
	input: RunSelection,
	now: string,
): FactoryRepo[] {
	if (input.scope === "selected") {
		const names = input.repos ?? [];
		if (new Set(names).size !== names.length) throw new Error("duplicate repository");
		return names.map((name) => {
			const repo = repos.find((r) => r.name === name);
			if (!repo) throw new Error("repository outside catalog");
			return repo;
		});
	}
	const query = input.query?.trim().toLowerCase();
	return repos.filter((repo) => {
		const state = states.find((s) => s.repo === repo.name);
		if (input.scope === "stale")
			return (
				!state?.refreshedAt ||
				state.status !== "success" ||
				Date.parse(now) - Date.parse(state.refreshedAt) >= 86400_000
			);
		if (input.scope === "failed") return state?.status === "failed";
		return (
			input.scope !== "filter" ||
			((!input.repo || repo.name === input.repo) &&
				(!input.language || repo.language === input.language) &&
				(!input.topic || repo.topics.includes(input.topic)) &&
				(!query || `${repo.name} ${repo.description ?? ""}`.toLowerCase().includes(query)))
		);
	});
}
export function makeRun(
	id: string,
	account: string,
	owner: string,
	requestKey: string,
	mode: FactoryRun["mode"],
	repos: FactoryRepo[],
	now: string,
	states: Pick<RepoRefreshState, "repo" | "refreshedAt" | "status" | "nextAllowedAt">[] = [],
	siteRepos: string[] = repos.map((repo) => repo.name),
	selection: RunSelection = { scope: "all" },
	depth: "quick" | "deep" = "deep",
	dailyPages = false,
): FactoryRun {
	const full = selection.scope === "all";
	const pageRepos = full
		? siteRepos
		: [
				...new Set([
					...repos.map((repo) => repo.name),
					...(selection.repos ?? []).filter((name) => siteRepos.includes(name)),
				]),
			];
	const step = (kind: StepKind, repo: string | null = null): FactoryRunStep => ({
		kind,
		repo,
		status: "pending",
		attempts: 0,
		startedAt: null,
		finishedAt: null,
		durationMs: 0,
		pages: 0,
		error: null,
	});
	const snapshot = (resource: string, repo: string | null = null): FactoryRunStep => ({
		...step("snapshot", repo),
		resource,
	});
	const steps =
		mode === "catalog"
			? [step("inventory"), snapshot("repos"), step("restore"), step("publish")]
			: [
					...(dailyPages && !full ? [snapshot("repos"), snapshot("notifications")] : []),
					...(full ? [...SITE_SNAPSHOT_KINDS, "insights"].map((kind) => snapshot(kind)) : []),
					...(full || dailyPages ? [step("contributions")] : []),
					...(depth === "quick" && (dailyPages || full) ? [step("activity-contributions")] : []),
					...repos.flatMap((r) => [
						step("metadata", r.name),
						...FACTORY_STREAMS.map((s) => step(s, r.name)),
						step("commit", r.name),
					]),
					...pageRepos.flatMap((repo) => [
						...REPO_SNAPSHOT_TABS.map((tab) => snapshot(`repo:${repo}:${tab}`, repo)),
					]),
					...(depth === "quick" && (dailyPages || full)
						? pageRepos
								.filter((repo) => repos.some((selected) => selected.name === repo))
								.map((repo) => step("activity", repo))
						: []),
					...(dailyPages && !full ? [snapshot("insights")] : []),
					step("publish"),
				];
	for (const s of steps)
		if (
			s.kind !== "snapshot" &&
			s.repo &&
			states.some((r) => r.repo === s.repo && r.nextAllowedAt > now)
		) {
			s.status = "skipped";
			s.error = "repository_cooldown";
			s.finishedAt = now;
		}
	return {
		id,
		account_id: account,
		owner,
		requestKey,
		mode,
		depth,
		trigger: "manual",
		selection: structuredClone(selection),
		repos: repos.map((r) => r.name),
		siteRepos: [...pageRepos],
		repoIds: Object.fromEntries(repos.map((r) => [r.name, r.id])),
		window: factoryWindow(now, depth === "quick" ? 30 : 90),
		steps,
		cursor: 0,
		status: "running",
		startedAt: now,
		updatedAt: now,
		finishedAt: null,
		nextAttemptAt: now,
		publishedAt: null,
		atomicPublication: true,
		requests: 0,
		version: 0,
		checkpoint: null,
		restoreCursor: 0,
	};
}
export function factoryRunDuration(
	steps: readonly (Pick<FactoryRunStep, "kind" | "durationMs"> &
		Partial<Pick<FactoryRunStep, "repo">>)[],
): number {
	const collection = new Map<string, number>();
	const snapshots = new Map<string, number>();
	let duration = 0;
	for (const step of steps) {
		const phase = step.repo
			? step.kind === "snapshot"
				? snapshots
				: step.kind === "metadata" ||
						step.kind === "commit" ||
						FACTORY_STREAMS.some((kind) => kind === step.kind)
					? collection
					: null
			: null;
		if (phase && step.repo) phase.set(step.repo, (phase.get(step.repo) ?? 0) + step.durationMs);
		else duration += step.durationMs;
	}
	for (const phase of [collection, snapshots]) {
		const lanes = Array.from({ length: FACTORY_REPO_CONCURRENCY }, () => 0);
		for (const repoDuration of phase.values()) {
			const availableAt = Math.min(...lanes);
			lanes[lanes.indexOf(availableAt)] = availableAt + repoDuration;
		}
		duration += Math.max(...lanes);
	}
	return duration;
}

export function runProgress(run: FactoryRun, now: string) {
	const count = (status: StepStatus) => run.steps.filter((s) => s.status === status).length;
	const success = count("success"),
		failed = count("failed"),
		unavailable = count("unavailable"),
		limited = count("limited"),
		skipped = count("skipped");
	const completed = success + failed + skipped + unavailable + limited;
	const measured = run.steps.filter((s) => s.status === "success" && s.durationMs > 0);
	const average = measured.length
		? measured.reduce((sum, s) => sum + s.durationMs, 0) / measured.length
		: null;
	return {
		total: run.steps.length,
		completed,
		success,
		failed,
		unavailable,
		limited,
		skipped,
		current: run.steps[run.cursor] ?? null,
		etaSeconds:
			run.status === "running" && average !== null
				? Math.ceil(
						factoryRunDuration(
							run.steps
								.filter((step) => step.status === "pending" || step.status === "running")
								.map((step) => ({ ...step, durationMs: average })),
						) /
							1000 +
							Math.max(0, Date.parse(run.nextAttemptAt) - Date.parse(now)) / 1000,
					)
				: null,
	};
}
export function completedRunStatus(run: Pick<FactoryRun, "steps">): "partial" | "completed" {
	return run.steps.some(
		(step) =>
			step.status === "failed" || (step.status === "skipped" && step.error !== "cloud_ai_retired"),
	)
		? "partial"
		: "completed";
}
export const retryDelay = (attempt: number) => Math.min(900, 30 * 2 ** Math.max(0, attempt - 1));
