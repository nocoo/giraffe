import { repoMetaTimestampSchema } from "../../lib/repo-meta";
import type { SecurityFeature } from "../../lib/security";
import { catalogCreationTimes, catalogIdentity } from "./catalog-history";
import { ApiError } from "./errors";
import type { GithubClient } from "./github-client";
import { TruncatedError } from "./github-client";
import {
	emptyTraffic,
	mapActionRuns,
	mapCodeScanningAlerts,
	mapContributors,
	mapDependabotAlerts,
	mapIssues,
	mapNotifications,
	mapPullRequests,
	mapReleases,
	mapRepoDetails,
	mapRepos,
	mapTraffic,
} from "./github-map";
import { githubUnavailability, unavailableReason } from "./github-unavailable";
import { PR_STATE_FIELDS } from "./pr-collect";

export type Collected = { truncated: boolean } & Record<string, unknown>;

export const MAX_STAGED_BYTES = 16 * 1024 * 1024;

const REPOS_QUERY =
	"query($after:String){ viewer { repositories(first:100, after:$after, affiliations:[OWNER, COLLABORATOR, ORGANIZATION_MEMBER]) { pageInfo { hasNextPage endCursor } nodes { id nameWithOwner name owner { login } description stargazerCount forkCount pushedAt createdAt isPrivate isArchived isFork visibility url primaryLanguage { name } issues(states:OPEN) { totalCount } } } } }";

const ISSUE_SEARCH =
	"query($q:String!,$after:String){ search(query:$q, type:ISSUE, first:100, after:$after){ issueCount pageInfo{ hasNextPage endCursor } nodes{ __typename ... on Issue { number title url state createdAt updatedAt author{ login } labels(first:100){ pageInfo{ hasNextPage } nodes{ name color } } comments{ totalCount } repository{ nameWithOwner } } } } }";

const PR_SEARCH = `query($q:String!,$after:String){ search(query:$q, type:ISSUE, first:100, after:$after){ issueCount pageInfo{ hasNextPage endCursor } nodes{ __typename ... on PullRequest { number title url state createdAt updatedAt author{ login } isDraft reviewDecision additions deletions baseRefName headRefName repository{ nameWithOwner } ${PR_STATE_FIELDS} } } } }`;

const ALERTS_QUERY =
	"query($o:String!,$n:String!,$after:String){ repository(owner:$o,name:$n){ vulnerabilityAlerts(first:20, after:$after, states:OPEN){ pageInfo{ hasNextPage endCursor } nodes{ id securityAdvisory{ summary permalink } securityVulnerability{ severity } } } } }";

export function utf8Bytes(text: string): number {
	return new TextEncoder().encode(text).length;
}

function arrayKey(payload: Record<string, unknown>): string | undefined {
	for (const [key, value] of Object.entries(payload)) {
		if (Array.isArray(value)) {
			return key;
		}
	}
	return undefined;
}

export function clampToBudget(
	payload: Collected,
	budget: number,
	kind = "",
): { payload: Collected; bytes: number; capped: boolean } {
	const limit = Math.max(0, budget);
	const encoded = JSON.stringify(payload);
	const size = utf8Bytes(encoded);
	if (size <= limit) {
		return { payload, bytes: size, capped: false };
	}
	const key = arrayKey(payload);
	if (!key || !Array.isArray(payload[key])) {
		const next = (
			kind
				? emptyCollected(kind, String(payload.fetched_at ?? ""))
				: { fetched_at: payload.fetched_at ?? "", truncated: true }
		) as Collected;
		const bytes = utf8Bytes(JSON.stringify(next));
		if (bytes > limit) {
			return { payload: next, bytes: 0, capped: true };
		}
		return { payload: next, bytes, capped: true };
	}
	const items = payload[key] as unknown[];
	let lo = 0;
	let hi = items.length;
	let best: Collected | undefined;
	let bestBytes = 0;
	while (lo <= hi) {
		const mid = (lo + hi) >> 1;
		const next = { ...payload, [key]: items.slice(0, mid), truncated: true };
		const bytes = utf8Bytes(JSON.stringify(next));
		if (bytes <= limit) {
			best = next;
			bestBytes = bytes;
			lo = mid + 1;
		} else {
			hi = mid - 1;
		}
	}
	if (best) {
		return { payload: best, bytes: bestBytes, capped: true };
	}
	const empty = { ...payload, [key]: [], truncated: true };
	const emptyBytes = utf8Bytes(JSON.stringify(empty));
	if (emptyBytes > limit) {
		return { payload: empty, bytes: 0, capped: true };
	}
	return { payload: empty, bytes: emptyBytes, capped: true };
}

export function ownerName(nameWithOwner: string): { owner: string; name: string } {
	const [owner, name] = nameWithOwner.split("/");
	return { owner: owner ?? "", name: name ?? "" };
}

export function nextPath(res: Response): string | null {
	const link = res.headers.get("link");
	if (!link) {
		return null;
	}
	const match = /<([^>]+)>\s*;\s*rel\s*=\s*(?:"next"|next\b)/i.exec(link);
	if (!match?.[1]) {
		if (/\brel\s*=\s*(?:"[^"]*\bnext\b[^"]*"|next\b)/i.test(link)) throw new TruncatedError();
		return null;
	}
	try {
		const url = new URL(match[1]);
		if (!["http:", "https:"].includes(url.protocol)) throw new TruncatedError();
		return `${url.pathname}${url.search}`;
	} catch {
		throw new TruncatedError();
	}
}

function skipSoft(err: unknown): boolean {
	return err instanceof ApiError && (err.code === "github_forbidden" || err.code === "not_found");
}

function isRecordList(
	value: unknown,
	nullable = false,
): value is (Record<string, unknown> | null)[] {
	return (
		Array.isArray(value) &&
		value.every((row) => (row === null ? nullable : typeof row === "object" && !Array.isArray(row)))
	);
}

function exceedsBudget(payload: Collected, budget: number): boolean {
	return utf8Bytes(JSON.stringify(payload)) > budget;
}

async function searchList(
	gh: GithubClient,
	token: string,
	repos: string[],
	isPr: boolean,
	budget = MAX_STAGED_BYTES,
): Promise<Collected> {
	const names = [...repos].sort();
	const items: unknown[] = [];
	let truncated = false;
	let stop = false;
	const query = isPr ? PR_SEARCH : ISSUE_SEARCH;
	for (let i = 0; i < names.length; i += 20) {
		if (stop) {
			break;
		}
		const group = names.slice(i, i + 20);
		const q = `${isPr ? "is:pr" : "is:issue"} is:open ${group.map((n) => `repo:${n}`).join(" ")}`;
		let after: string | null = null;
		let groupCount = 0;
		for (;;) {
			try {
				const data = await gh.githubGraphql(token, query, { q, after });
				const search = data.search as
					| {
							issueCount?: number;
							pageInfo?: { hasNextPage?: boolean; endCursor?: string | null };
							nodes?: unknown[];
					  }
					| undefined;
				if (
					i === 0 &&
					after === null &&
					!Array.isArray(search?.nodes) &&
					gh.graphqlErrors.length > 0 &&
					gh.graphqlErrors.every(
						(error) => error.type === "FORBIDDEN" || error.type === "NOT_FOUND",
					)
				) {
					if (gh.graphqlErrors.some((err) => err.type === "NOT_FOUND"))
						throw new ApiError(404, "not_found", "github not found");
					throw new ApiError(403, "github_forbidden", "github forbidden");
				}
				if (
					!isRecordList(search?.nodes, true) ||
					typeof search.pageInfo?.hasNextPage !== "boolean"
				) {
					truncated = true;
					stop = true;
					break;
				}
				const nodes = search.nodes.filter((node) => node !== null);
				items.push(...nodes);
				groupCount += nodes.length;
				const staged = isPr
					? ({ truncated: true, pull_requests: items } as Collected)
					: ({ truncated: true, issues: items } as Collected);
				if (exceedsBudget(staged, budget)) {
					truncated = true;
					stop = true;
					break;
				}
				const count = search.issueCount ?? 0;
				if (count >= 1000) {
					truncated = true;
				}
				if (gh.graphqlErrors.length > 0) {
					truncated = true;
					stop = true;
					break;
				}
				if (
					nodes.some((node) => {
						if (!node || typeof node !== "object") {
							return false;
						}
						const labels = (node as { labels?: { pageInfo?: { hasNextPage?: boolean } } }).labels;
						return labels?.pageInfo?.hasNextPage === true;
					})
				) {
					truncated = true;
				}
				if (search.pageInfo?.hasNextPage) {
					if (
						typeof search.pageInfo.endCursor !== "string" ||
						!search.pageInfo.endCursor ||
						search.pageInfo.endCursor === after
					) {
						truncated = true;
						break;
					}
					after = search.pageInfo.endCursor;
					continue;
				}
				if (count > groupCount) {
					truncated = true;
				}
				break;
			} catch (err) {
				if (err instanceof TruncatedError || (skipSoft(err) && (after !== null || i > 0))) {
					truncated = true;
					stop = true;
					break;
				}
				throw err;
			}
		}
	}
	const open = items.filter(
		(item) =>
			item &&
			typeof item === "object" &&
			!["CLOSED", "MERGED"].includes(String((item as Record<string, unknown>).state)),
	);
	const mapped = isPr ? mapPullRequests(open) : mapIssues(open);
	return isPr ? { truncated, pull_requests: mapped } : { truncated, issues: mapped };
}

export async function collectRepos(
	gh: GithubClient,
	token: string,
	budget = MAX_STAGED_BYTES,
): Promise<Collected> {
	const nodes: Array<Record<string, unknown>> = [];
	let after: string | null = null;
	let truncated = false;
	for (;;) {
		try {
			const data = await gh.githubGraphql(token, REPOS_QUERY, { after });
			const viewer = data.viewer as
				| {
						repositories?: {
							nodes?: Array<Record<string, unknown>>;
							pageInfo?: { hasNextPage?: boolean; endCursor?: string | null };
						};
				  }
				| undefined;
			const conn = viewer?.repositories;
			if (!isRecordList(conn?.nodes, true) || typeof conn.pageInfo?.hasNextPage !== "boolean") {
				truncated = true;
				break;
			}
			nodes.push(...conn.nodes.filter((node) => node !== null));
			if (conn.nodes.some((node) => node === null)) truncated = true;
			if (gh.graphqlErrors.length > 0) {
				truncated = true;
			}
			if (exceedsBudget({ truncated: true, repos: mapRepos(nodes) }, budget)) {
				truncated = true;
				break;
			}
			if (conn.pageInfo?.hasNextPage) {
				const next = conn.pageInfo.endCursor;
				if (typeof next !== "string" || !next || next === after) {
					truncated = true;
					break;
				}
				after = next;
				continue;
			}
			break;
		} catch (err) {
			if (err instanceof TruncatedError || (after !== null && skipSoft(err))) {
				truncated = true;
				break;
			}
			throw err;
		}
	}
	const payload = { truncated, repos: mapRepos(nodes) };
	const created: Record<string, string> = {};
	for (const node of nodes) {
		const time = repoMetaTimestampSchema.safeParse(node.createdAt);
		if (typeof node.id === "string" && node.id && time.success) created[node.id] = time.data;
	}
	catalogCreationTimes(payload, created);
	catalogIdentity(
		payload,
		Object.fromEntries(
			nodes
				.filter((node) => typeof node.id === "string" && node.id)
				.map((node) => [String(node.nameWithOwner).toLowerCase(), String(node.id)]),
		),
	);
	return payload;
}

export async function collectKind(
	gh: GithubClient,
	token: string,
	kind: string,
	repoNames: string[],
	budget = MAX_STAGED_BYTES,
): Promise<Collected> {
	if (kind === "issues") {
		return searchList(gh, token, repoNames, false, budget);
	}
	if (kind === "prs") {
		return searchList(gh, token, repoNames, true, budget);
	}
	if (kind === "alerts") {
		return collectAlerts(gh, token, repoNames, budget);
	}
	if (kind === "notifications") {
		return collectNotifications(gh, token, budget);
	}
	if (kind.startsWith("repo:")) {
		return collectRepoKind(gh, token, kind, budget);
	}
	throw new ApiError(400, "validation_failed", "unknown kind");
}

async function collectAlerts(
	gh: GithubClient,
	token: string,
	repoNames: string[],
	budget = MAX_STAGED_BYTES,
): Promise<Collected> {
	const names = [...repoNames].sort();
	const items: unknown[] = [];
	let truncated = names.length > 10;
	let dependabot = 0;
	let scanning = 0;
	let stop = false;
	let reason: ReturnType<typeof unavailableReason> | null = null;
	let dependabotOk = 0;
	let scanningOk = 0;
	let dependabotPartial = false;
	let scanningPartial = names.length > 10;
	let dependabotReason: ReturnType<typeof unavailableReason> | null = null;
	let scanningReason: ReturnType<typeof unavailableReason> | null = null;
	for (const full of names) {
		if (stop) {
			break;
		}
		const { owner, name } = ownerName(full);
		let after: string | null = null;
		let complete = false;
		for (;;) {
			try {
				const data = await gh.githubGraphql(token, ALERTS_QUERY, { o: owner, n: name, after });
				const repo = data.repository as {
					vulnerabilityAlerts?: {
						pageInfo?: { hasNextPage?: boolean; endCursor?: string | null };
						nodes?: unknown[];
					};
				} | null;
				if (gh.graphqlErrors.length > 0) {
					const error = gh.graphqlErrors[0];
					const denied = unavailableReason(
						error?.reasonCode ?? (error?.type === "NOT_FOUND" ? "not_found" : "unknown"),
					);
					reason ??= denied;
					dependabotReason ??= denied;
					dependabotPartial ||= after !== null || Array.isArray(repo?.vulnerabilityAlerts?.nodes);
					if (after !== null || Array.isArray(repo?.vulnerabilityAlerts?.nodes)) truncated = true;
					break;
				}
				if (
					!isRecordList(repo?.vulnerabilityAlerts?.nodes, true) ||
					typeof repo.vulnerabilityAlerts.pageInfo?.hasNextPage !== "boolean"
				) {
					truncated = true;
					dependabotPartial = true;
					break;
				}
				const nodes = repo.vulnerabilityAlerts.nodes.filter((node) => node !== null);
				dependabot += nodes.length;
				items.push(...mapDependabotAlerts(full, nodes));
				if (
					exceedsBudget(
						{
							truncated: true,
							unavailable: false,
							items,
							dependabot_open: dependabot,
							code_scanning_open: scanning,
						},
						budget,
					)
				) {
					truncated = true;
					stop = true;
					dependabotPartial = true;
					break;
				}
				if (repo.vulnerabilityAlerts?.pageInfo?.hasNextPage) {
					const next = repo.vulnerabilityAlerts.pageInfo.endCursor;
					if (typeof next !== "string" || !next || next === after) {
						truncated = true;
						dependabotPartial = true;
						break;
					}
					after = next;
					continue;
				}
				complete = true;
				break;
			} catch (err) {
				const denied = githubUnavailability(err);
				if (denied) {
					reason ??= denied;
					dependabotReason ??= denied;
					dependabotPartial ||= after !== null;
					if (after) truncated = true;
					break;
				}
				if (err instanceof TruncatedError) {
					truncated = true;
					stop = true;
					dependabotPartial = true;
					break;
				}
				throw err;
			}
		}
		if (complete) dependabotOk++;
	}
	for (const full of names.slice(0, 10)) {
		if (stop) {
			scanningPartial = true;
			break;
		}
		if (
			exceedsBudget(
				{
					truncated: true,
					unavailable: dependabotOk === 0 && scanningOk === 0,
					items,
					dependabot_open: dependabot,
					code_scanning_open: scanning,
				},
				budget,
			)
		) {
			truncated = true;
			scanningPartial = true;
			break;
		}
		const { owner, name } = ownerName(full);
		try {
			const res = await gh.githubApi(
				token,
				`/repos/${owner}/${name}/code-scanning/alerts?state=open&per_page=100`,
			);
			const body = (await res.json()) as unknown;
			if (!isRecordList(body)) {
				truncated = true;
				scanningPartial = true;
				break;
			}
			const mapped = mapCodeScanningAlerts(full, body);
			scanning += mapped.length;
			items.push(...mapped);
			if (nextPath(res)) {
				truncated = true;
				scanningPartial = true;
			} else scanningOk++;
		} catch (err) {
			const denied = githubUnavailability(err);
			if (denied) {
				reason ??= denied;
				scanningReason ??= denied;
				continue;
			}
			if (err instanceof TruncatedError) {
				truncated = true;
				scanningPartial = true;
				break;
			}
			throw err;
		}
	}
	const feature = (
		complete: number,
		partial: boolean,
		denied: ReturnType<typeof unavailableReason> | null,
	): SecurityFeature => ({
		status:
			partial || (complete > 0 && complete < names.length)
				? "partial"
				: complete === names.length
					? "available"
					: "unavailable",
		reason_code: denied?.reason_code ?? null,
		reason: denied?.reason ?? null,
	});
	const features = {
		dependabot: feature(dependabotOk, dependabotPartial, dependabotReason),
		code_scanning: feature(scanningOk, scanningPartial, scanningReason),
	};
	const unavailable = Object.values(features).every((value) => value.status === "unavailable");
	return {
		truncated,
		unavailable,
		...(unavailable ? reason : {}),
		features,
		items,
		dependabot_open:
			features.dependabot.status === "available" || dependabot > 0 ? dependabot : null,
		code_scanning_open:
			features.code_scanning.status === "available" || scanning > 0 ? scanning : null,
	};
}

async function collectNotifications(
	gh: GithubClient,
	token: string,
	budget = MAX_STAGED_BYTES,
): Promise<Collected> {
	return collectRestList(
		gh,
		token,
		"/notifications?per_page=100",
		(rows, truncated) => ({
			truncated,
			notifications: mapNotifications(rows),
		}),
		budget,
	);
}

export function emptyCollected(kind: string, fetchedAt: string): Collected {
	const base = { fetched_at: fetchedAt, truncated: true };
	if (kind === "repos") {
		return { ...base, repos: [] };
	}
	if (kind === "issues") {
		return { ...base, issues: [] };
	}
	if (kind === "prs") {
		return { ...base, pull_requests: [] };
	}
	if (kind === "alerts") {
		return {
			...base,
			unavailable: true,
			items: [],
			dependabot_open: null,
			code_scanning_open: null,
		};
	}
	if (kind === "notifications") {
		return { ...base, notifications: [] };
	}
	if (kind.endsWith(":details")) {
		return { ...base, ...mapRepoDetails({}) };
	}
	if (kind.endsWith(":actions")) {
		return { ...base, runs: [] };
	}
	if (kind.endsWith(":traffic")) {
		return { ...base, forbidden: false, views: emptyTraffic(), clones: emptyTraffic() };
	}
	if (kind.endsWith(":security")) {
		return { ...base, unavailable: true, dependabot_open: null, code_scanning_open: null };
	}
	if (kind.endsWith(":issues")) {
		return { ...base, issues: [] };
	}
	if (kind.endsWith(":prs")) {
		return { ...base, pull_requests: [] };
	}
	if (kind.endsWith(":releases")) {
		return { ...base, releases: [] };
	}
	if (kind.endsWith(":languages")) {
		return { ...base, languages: {} };
	}
	if (kind.endsWith(":contributors")) {
		return { ...base, contributors: [] };
	}
	return base;
}

async function collectRepoKind(
	gh: GithubClient,
	token: string,
	kind: string,
	budget = MAX_STAGED_BYTES,
): Promise<Collected> {
	const match = /^repo:([^/]+\/[^:]+):(.+)$/.exec(kind);
	if (!match?.[1] || !match[2]) {
		throw new ApiError(400, "validation_failed", "invalid repo kind");
	}
	const full = match[1];
	const suffix = match[2];
	const { owner, name } = ownerName(full);
	const base = `/repos/${owner}/${name}`;
	if (suffix === "details") {
		const res = await gh.githubApi(token, base);
		const body = (await res.json()) as Record<string, unknown>;
		return { truncated: false, ...mapRepoDetails(body) };
	}
	if (suffix === "actions") {
		return collectRestList(
			gh,
			token,
			`${base}/actions/runs?per_page=100`,
			(rows, truncated) => ({
				truncated,
				runs: mapActionRuns({ workflow_runs: rows }),
			}),
			budget,
			"workflow_runs",
		);
	}
	if (suffix === "traffic") {
		try {
			const views = await gh.githubApi(token, `${base}/traffic/views`);
			const viewsBody = mapTraffic(await views.json(), "views");
			const afterViews = {
				truncated: true,
				forbidden: false,
				views: viewsBody,
				clones: emptyTraffic(),
			};
			if (exceedsBudget(afterViews, budget)) {
				return afterViews;
			}
			const clones = await gh.githubApi(token, `${base}/traffic/clones`);
			return {
				truncated: false,
				forbidden: false,
				views: viewsBody,
				clones: mapTraffic(await clones.json(), "clones"),
			};
		} catch (err) {
			if (skipSoft(err)) {
				return { truncated: false, forbidden: true, views: emptyTraffic(), clones: emptyTraffic() };
			}
			if (err instanceof TruncatedError) {
				return { truncated: true, forbidden: false, views: emptyTraffic(), clones: emptyTraffic() };
			}
			throw err;
		}
	}
	if (suffix === "security") {
		return collectAlerts(gh, token, [full], budget);
	}

	if (suffix === "issues") {
		return searchList(gh, token, [full], false, budget);
	}
	if (suffix === "prs") {
		return searchList(gh, token, [full], true, budget);
	}
	if (suffix === "releases") {
		return collectRestList(
			gh,
			token,
			`${base}/releases?per_page=100`,
			(rows, truncated) => ({
				truncated,
				releases: mapReleases(rows),
			}),
			budget,
		);
	}
	if (suffix === "languages") {
		const res = await gh.githubApi(token, `${base}/languages`);
		const languages = (await res.json()) as unknown;
		return { truncated: false, languages };
	}
	if (suffix === "contributors") {
		return collectRestList(
			gh,
			token,
			`${base}/contributors?per_page=100`,
			(rows, truncated) => ({
				truncated,
				contributors: mapContributors(rows),
			}),
			budget,
		);
	}
	throw new ApiError(400, "validation_failed", "unknown repo kind");
}

async function collectRestList(
	gh: GithubClient,
	token: string,
	start: string,
	finish: (rows: unknown[], truncated: boolean) => Collected,
	budget = MAX_STAGED_BYTES,
	responseKey?: "workflow_runs",
): Promise<Collected> {
	const collected = finish([], false);
	let path: string | null = start;
	let truncated = false;
	let started = false;
	while (path) {
		try {
			const res = await gh.githubApi(token, path);
			const body = (await res.json()) as unknown;
			const items =
				responseKey === undefined
					? body
					: body && typeof body === "object"
						? (body as Record<string, unknown>)[responseKey]
						: null;
			if (!isRecordList(items)) {
				truncated = true;
				break;
			}
			const page = finish(items, false);
			for (const [key, value] of Object.entries(page))
				if (Array.isArray(value)) (collected[key] as unknown[]).push(...value);
			started = true;
			path = nextPath(res);
			if (exceedsBudget({ ...collected, truncated: true }, budget)) {
				truncated = true;
				break;
			}
		} catch (err) {
			if (err instanceof TruncatedError || (started && skipSoft(err))) {
				truncated = true;
				break;
			}
			throw err;
		}
	}
	return { ...collected, truncated };
}
