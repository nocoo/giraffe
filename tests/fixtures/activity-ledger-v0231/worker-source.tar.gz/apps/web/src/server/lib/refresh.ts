import { securityIncomplete } from "../../lib/security";
import { REPO_SNAPSHOT_TABS, SITE_SNAPSHOT_KINDS } from "../../lib/snapshot-kinds";
import {
	beginCatalog,
	type CatalogPlan,
	catalogIdentity,
	catalogPlanWrites,
	catalogSnapshot,
	planCatalog,
} from "./catalog-history";
import {
	type Collected,
	clampToBudget,
	collectKind,
	collectRepos,
	MAX_STAGED_BYTES,
} from "./collect";
import { getAccount, touchLastUsedStmt } from "./db/accounts";
import type { Db } from "./db/d1";
import { pruneDaysStmt } from "./db/snapshot-days";
import { readSnapshot, replaceSnapshotStmts } from "./db/snapshots";
import { ApiError } from "./errors";
import { type GithubClient, MAX_FETCHES } from "./github-client";
import type { Capabilities } from "./github-map";
import { buildInsights, type InsightAlert, type RepoRow } from "./insights";
import { assemblePages, splitPages } from "./snapshot-pages";
import { repoPolicy } from "./snapshot-projection";

const ALL = SITE_SNAPSHOT_KINDS;
const DERIVED = new Set(["insights"]);
const CROSS = new Set<string>(ALL);
const SUFFIX = new Set<string>(REPO_SNAPSHOT_TABS);

export function assertKind(kind: string): void {
	if (CROSS.has(kind) || DERIVED.has(kind)) {
		return;
	}
	const match = /^repo:([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+):([a-z]+)$/.exec(kind);
	if (!match?.[1] || !match[2] || !match[3] || !SUFFIX.has(match[3])) {
		throw new ApiError(400, "validation_failed", "unknown kind");
	}
	if (match[1] === "." || match[1] === ".." || match[2] === "." || match[2] === "..") {
		throw new ApiError(400, "validation_failed", "invalid repo kind");
	}
}

export function expandKinds(raw: "all" | string[] | undefined): string[] {
	if (raw === undefined || raw === "all") {
		return [...ALL];
	}
	if (raw.length === 0 || raw.length > 16) {
		throw new ApiError(400, "validation_failed", "invalid kinds");
	}
	if (new Set(raw).size !== raw.length) {
		throw new ApiError(400, "validation_failed", "duplicate kinds");
	}
	for (const kind of raw) {
		assertKind(kind);
	}
	return raw;
}

function githubOrder(kinds: string[]): string[] {
	const github = kinds.filter((kind) => !DERIVED.has(kind));
	const rest = github.filter((kind) => kind !== "repos");
	return github.includes("repos") ? ["repos", ...rest] : rest;
}

function parseCaps(raw: string): Capabilities {
	try {
		return JSON.parse(raw) as Capabilities;
	} catch {
		return { repo: false, "read:org": false, "read:user": false, notifications: false };
	}
}

function assertCaps(kind: string, caps: Capabilities): void {
	if (DERIVED.has(kind)) {
		return;
	}
	if (kind === "notifications") {
		if (!caps.notifications) {
			throw new ApiError(409, "capability_missing", "notifications scope missing");
		}
		return;
	}
	if (!caps.repo) {
		throw new ApiError(409, "capability_missing", "repo scope missing");
	}
}

function needsRepoNames(kind: string): boolean {
	return kind === "issues" || kind === "prs" || kind === "alerts";
}

export function assertRefreshCapabilities(raw: string, kinds: string[]) {
	const caps = parseCaps(raw);
	for (const kind of kinds) assertCaps(kind, caps);
}

function asRepos(payload: Collected): RepoRow[] {
	const rows = payload.repos;
	if (!Array.isArray(rows)) {
		return [];
	}
	return rows.map((row) => {
		const r = row as Record<string, unknown>;
		return {
			name_with_owner: String(r.name_with_owner ?? ""),
			open_issue_count: Number(r.open_issue_count ?? 0),
			pushed_at: typeof r.pushed_at === "string" ? r.pushed_at : null,
		};
	});
}

function sourceOk(payload: Collected | null): boolean {
	return payload !== null && payload.truncated !== true;
}

/** Prepare only: the caller chooses the transaction, including the factory lease fence. */
export async function prepareRefresh(
	db: Db,
	accountId: string,
	gh: GithubClient,
	token: string,
	requested: string[],
	fetchedAt: string,
	written: Record<string, Collected> = {},
	options: {
		deriveInsights?: boolean;
		deferCatalog?: boolean;
		catalogRunId?: string;
		stageRunId?: string;
	} = {},
) {
	const owner = (await getAccount(db, accountId))?.login.toLowerCase();
	const catalogBaseline = requested.includes("repos") ? await beginCatalog(db, accountId) : null;
	let catalogPlan: CatalogPlan | null = null;
	let preserveCatalog = false;
	for (const kind of requested) {
		if (kind.startsWith("repo:") && kind.slice(5).split("/")[0]?.toLowerCase() !== owner)
			throw new ApiError(400, "validation_failed", "repository is not account-owned");
	}
	async function loaded(kind: string): Promise<Collected | null> {
		const current = written[kind];
		if (current) {
			return current;
		}
		const snap = await readSnapshot(db, accountId, kind, options.stageRunId);
		return snap as Collected | null;
	}

	async function repoNames(): Promise<string[]> {
		const payload = await loaded("repos");
		const repos = payload?.repos;
		if (!payload || !Array.isArray(repos)) {
			throw new ApiError(409, "snapshot_missing", "repos snapshot missing");
		}
		return repos
			.map((row) => String((row as { name_with_owner?: string }).name_with_owner ?? ""))
			.filter((name) => name.split("/")[0]?.toLowerCase() === owner);
	}

	let used = 0;
	let stop = false;
	for (const kind of githubOrder(requested)) {
		if (written[kind]) continue;
		if (stop) {
			break;
		}
		const remaining = MAX_STAGED_BYTES - used;
		let payload: Collected =
			kind === "repos"
				? await collectRepos(gh, token, remaining)
				: await collectKind(
						gh,
						token,
						kind,
						needsRepoNames(kind) ? await repoNames() : [],
						remaining,
					);
		if (kind === "repos" && catalogBaseline) {
			catalogPlan = await planCatalog(
				catalogBaseline,
				payload,
				catalogIdentity(payload),
				owner ?? "",
				gh,
				token,
				fetchedAt,
				{ kind: options.deferCatalog ? "factory" : "legacy", runId: options.catalogRunId ?? null },
			);
			if (!catalogPlan.complete) {
				preserveCatalog = true;
				if (catalogBaseline.saved) written.repos = catalogBaseline.saved as Collected;
				if (!catalogBaseline.saved)
					throw new ApiError(422, "snapshot_incomplete", "Catalog listing is incomplete");
				break;
			}
			payload = catalogSnapshot(catalogPlan);
		}
		if (needsRepoNames(kind)) {
			const reposPayload = await loaded("repos");
			if (reposPayload?.truncated === true) {
				payload = { ...payload, truncated: true };
			}
		}
		payload = { ...payload, fetched_at: fetchedAt };
		const clamped = clampToBudget(payload, MAX_STAGED_BYTES - used, kind);
		if (clamped.capped && clamped.bytes === 0) {
			stop = true;
			break;
		}
		const preview = splitPages(kind, clamped.payload);
		if (kind === "repos" && catalogPlan?.complete && (clamped.capped || preview.truncated))
			throw new ApiError(422, "catalog_capacity", "Catalog exceeds bounded snapshot capacity");
		written[kind] = { ...assemblePages(kind, preview.pages), truncated: preview.truncated };
		used += clamped.bytes;
		if (clamped.capped || gh.count >= MAX_FETCHES || used >= MAX_STAGED_BYTES) {
			stop = true;
		}
	}

	if (
		options.deriveInsights !== false &&
		requested.some((kind) => CROSS.has(kind) || DERIVED.has(kind))
	) {
		const explicitInsights = requested.includes("insights");
		const reposSrc = await loaded("repos");
		const issuesSrc = await loaded("issues");
		const alertsSrc = await loaded("alerts");
		const policy = await repoPolicy(db, accountId, reposSrc);
		const insightsOk = sourceOk(reposSrc) && sourceOk(issuesSrc);
		if (explicitInsights && !insightsOk) {
			throw new ApiError(409, "snapshot_missing", "derived sources missing");
		}
		if (insightsOk && reposSrc) {
			const alertsIncomplete = securityIncomplete(alertsSrc);
			const insights = buildInsights(
				asRepos(reposSrc).filter((r) => policy.includes(r.name_with_owner)),
				Array.isArray(alertsSrc?.items) ? (alertsSrc.items as InsightAlert[]) : [],
				fetchedAt,
				alertsIncomplete,
			);
			const preview = splitPages("insights", insights);
			if (!preview.truncated || explicitInsights) {
				written.insights = {
					...assemblePages("insights", preview.pages),
					truncated: preview.truncated,
				};
			}
		}
	}

	const stmts = [];
	if (catalogPlan && !options.deferCatalog) {
		stmts.push(
			db
				.prepare(
					"SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM factory_runs WHERE account_id=? AND status IN ('running','paused')) THEN 1 ELSE json('{') END",
				)
				.bind(accountId),
		);
		stmts.push(...catalogPlanWrites(db, accountId, catalogPlan));
	}
	for (const [kind, payload] of Object.entries(written)) {
		if (kind === "repos" && (preserveCatalog || options.deferCatalog)) continue;
		const preview = splitPages(kind, payload);
		payload.truncated = preview.truncated;
		stmts.push(
			...(await replaceSnapshotStmts(db, accountId, kind, payload, fetchedAt, options.stageRunId)),
		);
	}
	const cutoff = new Date(Date.parse(fetchedAt) - 29 * 86_400_000).toISOString().slice(0, 10);
	stmts.push(pruneDaysStmt(db, accountId, cutoff));
	if (gh.count > 0) {
		stmts.push(touchLastUsedStmt(db, accountId, fetchedAt));
	}
	return { written, stmts, catalogPlan };
}
