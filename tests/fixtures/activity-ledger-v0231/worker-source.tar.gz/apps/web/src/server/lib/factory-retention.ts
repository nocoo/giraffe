import type { Db } from "./db/d1";
export type FactoryStorage = { resourceBytes: number; totalBytes: number };
export function factoryStorageStatement(db: Db, account: string): D1PreparedStatement {
	return db
		.prepare(`SELECT
 COALESCE((SELECT bytes FROM factory_storage WHERE account_id=?),0) AS resourceBytes,
 COALESCE((SELECT bytes FROM factory_budget WHERE account_id=?),0) + (SELECT COALESCE(SUM(bytes),0) FROM (
		SELECT length(CAST(payload AS BLOB)) AS bytes FROM snapshots WHERE account_id=? AND kind NOT LIKE 'factory%'
		UNION ALL SELECT length(CAST(payload AS BLOB)) FROM snapshot_days WHERE account_id=?
		UNION ALL SELECT length(CAST(j.journal AS BLOB)) FROM factory_run_journal j JOIN factory_runs r ON r.id=j.run_id WHERE r.account_id=?
		UNION ALL SELECT length(CAST(COALESCE(input,'')||COALESCE(judgment,'')||COALESCE(report,'') AS BLOB)) FROM ai_reviews WHERE account_id=?
 UNION ALL SELECT length(CAST(a.diagnostic AS BLOB)) FROM ai_review_attempts a JOIN ai_reviews r ON r.job_id=a.job_id WHERE r.account_id=?
	))
	 + (SELECT COALESCE(SUM(length(CAST(identity_key||COALESCE(github_id,'')||repo||row_payload||COALESCE(first_seen_at,'')||COALESCE(last_seen_at,'')||COALESCE(removed_at,'')||COALESCE(archived_changed_at,'')||visibility||first_seen_source||COALESCE(last_source_run_id,'') AS BLOB))),0) FROM catalog_repositories WHERE account_id=?)
	 + (SELECT COALESCE(SUM(length(CAST(event_id||kind||repo||COALESCE(github_id,'')||at||source_kind||COALESCE(source_run_id,'')||details AS BLOB))),0) FROM catalog_changes WHERE account_id=?)
	 + (SELECT COALESCE(SUM(length(CAST(event_id||repo||COALESCE(github_id,'')||at||source_kind||COALESCE(source_run_id,'')||reason AS BLOB))),0) FROM catalog_unconfirmed WHERE account_id=?)
	 + (SELECT COALESCE(SUM(length(CAST(identity_key||table_name||repo||COALESCE(version,'')||payload AS BLOB))),0) FROM catalog_displaced_state WHERE account_id=?)
	 + (SELECT COALESCE(SUM(length(CAST(history_since||COALESCE(checked_at,'')||COALESCE(source_run_id,'')||COALESCE(warning_code,'') AS BLOB))),0) FROM catalog_state WHERE account_id=?) AS totalBytes`)
		.bind(
			account,
			account,
			account,
			account,
			account,
			account,
			account,
			account,
			account,
			account,
			account,
			account,
		);
}
export function decodeFactoryStorage(row: FactoryStorage | undefined | null): FactoryStorage {
	return {
		resourceBytes: row?.resourceBytes ?? 0,
		totalBytes: row?.totalBytes ?? 0,
	};
}
export async function factoryStorage(db: Db, account: string) {
	return decodeFactoryStorage(await factoryStorageStatement(db, account).first<FactoryStorage>());
}
/** Bounded GC. Current heads, their manifests, two latest publications and 20 recent runs are roots. */
export async function pruneFactory(db: Db, now: string) {
	const cutoff = new Date(Date.parse(now) - 7 * 86400_000).toISOString();
	await db.batch([
		db
			.prepare(`DELETE FROM activity_publications WHERE (account_id,run_id) IN (
 SELECT a.account_id,a.run_id FROM activity_publications a WHERE a.fetched_at<?
 AND a.run_id NOT IN (SELECT p.run_id FROM activity_publications p JOIN factory_runs r ON r.id=p.run_id AND r.account_id=p.account_id WHERE p.account_id=a.account_id AND r.status IN ('completed','partial') ORDER BY p.until_at DESC,p.run_id LIMIT 2)
 AND a.run_id NOT IN (SELECT r.id FROM factory_runs r WHERE r.account_id=a.account_id ORDER BY r.created_at DESC LIMIT 20) LIMIT 50)`)
			.bind(cutoff),
		db
			.prepare(`DELETE FROM snapshots WHERE (account_id,kind) IN (
   SELECT s.account_id,s.kind FROM snapshots s WHERE (s.kind LIKE 'factory:v:%' OR s.kind LIKE 'factory:catalog:%') AND s.fetched_at<?
   AND NOT EXISTS(SELECT 1 FROM factory_state h WHERE h.account_id=s.account_id AND (s.kind IN ('factory:v:'||h.published_id,'factory:v:'||h.published_id||'#2','factory:catalog:'||h.catalog_id,'factory:catalog:'||h.catalog_id||'#2')))
   AND NOT EXISTS(SELECT 1 FROM (SELECT id FROM factory_runs r WHERE r.account_id=s.account_id ORDER BY created_at DESC LIMIT 20) recent WHERE s.kind IN ('factory:v:'||recent.id,'factory:v:'||recent.id||'#2','factory:catalog:'||recent.id,'factory:catalog:'||recent.id||'#2'))
   AND NOT EXISTS(SELECT 1 FROM (SELECT kind FROM snapshots p WHERE p.account_id=s.account_id AND p.kind LIKE 'factory:v:%' AND instr(p.kind,'#')=0 ORDER BY fetched_at DESC LIMIT 2) latest WHERE s.kind IN (latest.kind,latest.kind||'#2')) LIMIT 50)`)
			.bind(cutoff),
		db.prepare(
			"DELETE FROM factory_version_refs WHERE (account_id,publication_id,repo) IN (SELECT f.account_id,f.publication_id,f.repo FROM factory_version_refs f WHERE NOT EXISTS(SELECT 1 FROM snapshots s WHERE s.account_id=f.account_id AND s.kind='factory:v:'||f.publication_id) LIMIT 100)",
		),
		db
			.prepare(`DELETE FROM factory_repo_versions WHERE (account_id,repo,version) IN (SELECT v.account_id,v.repo,v.version FROM factory_repo_versions v WHERE v.refreshed_at<?
   AND NOT EXISTS(SELECT 1 FROM factory_repo_state s WHERE s.account_id=v.account_id AND COALESCE(json_extract(s.payload,'$.observation.repo'),s.repo)=v.repo AND s.version=v.version)
   AND NOT EXISTS(SELECT 1 FROM catalog_displaced_state d WHERE d.account_id=v.account_id AND d.table_name='factory_repo_state' AND COALESCE(json_extract(d.payload,'$.observation.repo'),d.repo)=v.repo AND d.version=v.version)
   AND NOT EXISTS(SELECT 1 FROM factory_version_refs f WHERE f.account_id=v.account_id AND f.repo=v.repo AND f.version=v.version)
   AND v.version NOT IN(SELECT id FROM factory_runs r WHERE r.account_id=v.account_id ORDER BY created_at DESC LIMIT 20) LIMIT 50)`)
			.bind(cutoff),
		db
			.prepare(`DELETE FROM factory_resources WHERE (run_id,repo,stream) IN (SELECT s.run_id,s.repo,s.stream FROM factory_resources s JOIN factory_runs r ON r.id=s.run_id WHERE r.status NOT IN ('running','paused') AND r.created_at<?
   AND r.id NOT IN(SELECT id FROM factory_runs recent WHERE recent.account_id=r.account_id ORDER BY created_at DESC LIMIT 20)
   AND NOT EXISTS(SELECT 1 FROM factory_repo_state h WHERE h.account_id=r.account_id AND COALESCE(json_extract(h.payload,'$.observation.repo'),h.repo)=s.repo AND h.version=s.run_id)
   AND NOT EXISTS(SELECT 1 FROM catalog_displaced_state d WHERE d.account_id=r.account_id AND d.table_name='factory_repo_state' AND COALESCE(json_extract(d.payload,'$.observation.repo'),d.repo)=s.repo AND d.version=s.run_id)
   AND NOT EXISTS(SELECT 1 FROM factory_version_refs f WHERE f.account_id=r.account_id AND f.repo=s.repo AND f.version=s.run_id AND f.source='run') LIMIT 50)`)
			.bind(cutoff),
		db
			.prepare(`DELETE FROM factory_runs WHERE id IN (SELECT r.id FROM factory_runs r WHERE r.status NOT IN ('running','paused') AND r.created_at<?
   AND r.id NOT IN(SELECT id FROM factory_runs recent WHERE recent.account_id=r.account_id ORDER BY created_at DESC LIMIT 20)
   AND NOT EXISTS(SELECT 1 FROM catalog_displaced_state d WHERE d.account_id=r.account_id AND d.table_name='factory_repo_state' AND d.version=r.id)
   AND NOT EXISTS(SELECT 1 FROM factory_resources s WHERE s.run_id=r.id)
   AND NOT EXISTS(SELECT 1 FROM factory_repo_versions v WHERE v.account_id=r.account_id AND v.version=r.id)
   AND NOT EXISTS(SELECT 1 FROM factory_version_refs f WHERE f.account_id=r.account_id AND (f.version=r.id OR f.publication_id=r.id))
	 AND NOT EXISTS(SELECT 1 FROM activity_publications a WHERE a.account_id=r.account_id AND a.run_id=r.id)
   AND NOT EXISTS(SELECT 1 FROM snapshots s WHERE s.account_id=r.account_id AND s.kind IN ('factory:v:'||r.id,'factory:catalog:'||r.id)) LIMIT 50)`)
			.bind(cutoff),
	]);
}
