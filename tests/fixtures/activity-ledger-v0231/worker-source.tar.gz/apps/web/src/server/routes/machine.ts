import { Hono } from "hono";
import { etag, RETAINED_304_HEADERS } from "hono/etag";
import { resourceCollection, resourceId } from "../../lib/agent-resource";
import { REPO_SNAPSHOT_TABS } from "../../lib/snapshot-kinds";
import type { AppVars, Env } from "../env";
import { readActivity } from "../lib/activity-store";
import {
	createResource,
	deleteResource,
	getResource,
	listResources,
	updateResource,
} from "../lib/agent-resources";
import { authenticateApiToken, recordApiTokenUse } from "../lib/api-tokens";
import { catalogInclude, readCatalogChanges } from "../lib/catalog-read";
import { getAccount } from "../lib/db/accounts";
import { createDb } from "../lib/db/d1";
import { ApiError } from "../lib/errors";
import { readContributions } from "../lib/machine-contributions";
import {
	readMachineAccountObservation,
	readMachineFactoryStream,
	readMachineRepositoryObservation,
} from "../lib/machine-observations";
import { assertMachineQuery } from "../lib/machine-query";
import { readSources } from "../lib/machine-sources";
import { readJson } from "../lib/read-body";
import { enrichRepoAgentStates } from "../lib/repo-agent-state";
import { enrichRepoMeta } from "../lib/repo-meta";
import type { AccountObservationResource } from "../lib/saved-observation-statements";
import { snapshotScope } from "../lib/snapshot-scope";
import { SourceTiming } from "../lib/source-timing";
import { timedJson } from "../lib/timed-json";
import { activityEtag } from "./activity";
import {
	getMachineSettings,
	getMachineStars,
	machineRuns,
	machineSetting,
} from "./machine-settings";
import { machineRepoAgentState } from "./repo-agent-state";
import { machineRepoMeta } from "./repo-meta";
import { latestReport } from "./report-latest";
import { getMachineLatestRun } from "./run-readiness";

type Principal = NonNullable<Awaited<ReturnType<typeof authenticateApiToken>>>;
export type MachineVars = AppVars & {
	principal: Principal;
	starUnchanged: boolean | undefined;
};
export function machineApi() {
	const app = new Hono<{ Bindings: Env; Variables: MachineVars }>();
	app.use("*", async (c, next) => {
		await next();
		c.header("Cache-Control", "private, no-store");
		const vary =
			c.res.headers
				.get("Vary")
				?.split(",")
				.map((value) => value.trim()) ?? [];
		if (!vary.some((value) => value.toLowerCase() === "authorization"))
			c.header("Vary", [...vary, "Authorization"].join(", "));
		c.header("Referrer-Policy", "no-referrer");
	});
	app.use("*", async (c, next) => {
		const timing =
			c.req.method === "GET" &&
			/^\/api\/v1\/accounts\/[^/]+\/(?:sources$|repos(?:\/|$)|issues$|prs$|ci$|factory(?:\/|$)|contributions$|settings$|refresh-runs$)/.test(
				c.req.path,
			)
				? new SourceTiming()
				: undefined;
		c.set("sourceTiming", timing);
		c.set("db", createDb(c.env.DB, timing?.recordD1.bind(timing)));
		const authenticate = () =>
			authenticateApiToken(c.get("db"), c.req.header("Authorization") ?? null);
		const principal = timing
			? await timing.measureAsync("auth", authenticate)
			: await authenticate();
		if (!principal) throw new ApiError(401, "token_unauthorized", "invalid API token");
		c.set("principal", principal);
		const account = c.req.path.match(/^\/api\/v1\/accounts\/([^/]+)/)?.[1];
		if (account && decodeURIComponent(account) !== principal.accountId)
			throw new ApiError(403, "account_forbidden", "token belongs to another account");
		if (c.req.path !== "/api/v1/me") {
			const read = c.req.method === "GET";
			const agent = /^\/api\/v1\/accounts\/[^/]+\/agent\//.test(c.req.path);
			const management =
				/^\/api\/v1\/accounts\/[^/]+\/(settings|stars|statistics|schedules|refresh-runs)(\/|$)/.test(
					c.req.path,
				) ||
				/^\/api\/v1\/accounts\/[^/]+\/repos\/[^/]+\/[^/]+\/(agent-state|meta)$/.test(c.req.path);
			const scope = agent
				? read
					? "agent:read"
					: "agent:write"
				: management
					? read
						? "app:read"
						: "app:write"
					: "observations:read";
			if (!principal.scopes.includes(scope))
				throw new ApiError(403, "scope_forbidden", "scope required");
			if (!read && !agent && !management)
				throw new ApiError(405, "method_not_allowed", "observations are read-only");
		}
		if (timing) await timing.measureAsync("build", next);
		else await next();
		if (timing && (c.res.status === 200 || c.res.status === 304))
			c.header("Server-Timing", timing.header());
		if (!["GET", "HEAD"].includes(c.req.method) && c.res.status < 400 && !c.get("starUnchanged"))
			await recordApiTokenUse(c.get("db"), principal.accountId, principal.id);
	});
	app.get("/me", async (c) => {
		assertMachineQuery(c.req.query());
		const p = c.get("principal");
		const account = await getAccount(c.get("db"), p.accountId);
		if (!account) throw new ApiError(401, "token_unauthorized", "account unavailable");
		return c.json({
			account_id: p.accountId,
			login: account.login,
			token: { id: p.id, scopes: p.scopes, expires_at: p.expiresAt },
			capabilities: {
				observations: p.scopes.includes("observations:read"),
				agentRead: p.scopes.includes("agent:read"),
				agentWrite: p.scopes.includes("agent:write"),
				appRead: p.scopes.includes("app:read"),
				appWrite: p.scopes.includes("app:write"),
			},
		});
	});
	app.get("/accounts/:account/agent/reports/latest", latestReport);
	app.all("/accounts/:account/agent/:collection/:id?", async (c) => {
		const kind = resourceCollection.safeParse(c.req.param("collection"));
		const id = c.req.param("id");
		if (!kind.success || (id && !resourceId.safeParse(id).success))
			throw new ApiError(404, "not_found", "unknown resource");
		const db = c.get("db");
		const account = c.get("principal").accountId;
		const method = c.req.method;
		if (method === "GET" && !id)
			return c.json(await listResources(db, account, kind.data, c.req.query()));
		if (method === "GET" && id) {
			assertMachineQuery(c.req.query());
			const item = await getResource(db, account, kind.data, id);
			if (!item) throw new ApiError(404, "not_found", "resource not found");
			return c.json({ account_id: account, item });
		}
		if (method === "POST" && !id) {
			const item = await createResource(db, account, kind.data, await readJson(c.req.raw, 70000));
			return c.json(
				{ account_id: account, item },
				kind.data === "reports" && item.type === "github-daily" && item.revision > 1 ? 200 : 201,
			);
		}
		if (method === "PATCH" && id)
			return c.json({
				account_id: account,
				item: await updateResource(db, account, kind.data, id, await readJson(c.req.raw, 70000)),
			});
		if (method === "DELETE" && id) {
			await deleteResource(db, account, kind.data, id, Number(c.req.query("revision")));
			return c.body(null, 204);
		}
		throw new ApiError(405, "method_not_allowed", "method not allowed");
	});
	app.get("/accounts/:account/settings", (c) => {
		assertMachineQuery(c.req.query());
		return getMachineSettings(c);
	});
	app.get(
		"/accounts/:account/sources",
		async (c, next) =>
			etag({
				weak: false,
				generateDigest: (body) => {
					const hash = () => crypto.subtle.digest("SHA-256", body);
					return c.get("sourceTiming")?.measureAsync("hash", hash) ?? hash();
				},
				retainedHeaders: [...RETAINED_304_HEADERS, "referrer-policy"],
			})(c, next),
		async (c) => {
			const timing = c.get("sourceTiming");
			const read = () =>
				readSources(c.get("db"), c.get("principal").accountId, c.req.query(), timing);
			const data = timing ? await timing.measureAsync("build", read) : await read();
			return timing
				? c.body(timing.stringify(data), 200, { "Content-Type": "application/json" })
				: c.json(data);
		},
	);
	app.get("/accounts/:account/stars", getMachineStars);
	app.all(
		"/accounts/:account/catalog/changes",
		async (c, next) => {
			if (c.req.method !== "GET")
				throw new ApiError(405, "method_not_allowed", "Catalog history is read-only");
			await next();
		},
		etag({ weak: false, retainedHeaders: [...RETAINED_304_HEADERS, "referrer-policy"] }),
		async (c) =>
			c.json(await readCatalogChanges(c.get("db"), c.get("principal").accountId, c.req.queries())),
	);
	app.get("/accounts/:account/activity", activityEtag, async (c) =>
		c.json(await readActivity(c.get("db"), c.get("principal").accountId, c.req.queries())),
	);
	app.all("/accounts/:account/stars/:owner/:name", machineSetting);
	app.get(
		"/accounts/:account/contributions",
		async (c, next) =>
			etag({
				weak: false,
				generateDigest: (body) => {
					const hash = () => crypto.subtle.digest("SHA-256", body);
					return c.get("sourceTiming")?.measureAsync("hash", hash) ?? hash();
				},
				retainedHeaders: [...RETAINED_304_HEADERS, "referrer-policy"],
			})(c, next),
		async (c) =>
			timedJson(
				c,
				await readContributions(c.get("db"), c.get("principal").accountId, c.req.queries()),
			),
	);
	app.all("/accounts/:account/statistics/:owner/:name", machineSetting);
	app.all("/accounts/:account/schedules/:kind", machineSetting);
	app.all("/accounts/:account/refresh-runs", machineRuns);
	app.all("/accounts/:account/refresh-runs/latest", getMachineLatestRun);
	app.all("/accounts/:account/refresh-runs/:id/control", machineRuns);
	app.get("/accounts/:account/factory/repos/:owner/:name/:stream", async (c) => {
		assertMachineQuery(c.req.query());
		return timedJson(
			c,
			await readMachineFactoryStream(
				c.get("db"),
				c.get("principal").accountId,
				`${c.req.param("owner")}/${c.req.param("name")}`,
				c.req.param("stream"),
			),
		);
	});
	app.all("/accounts/:account/repos/:owner/:name/meta", machineRepoMeta);
	app.all("/accounts/:account/repos/:owner/:name/agent-state", machineRepoAgentState);
	app.get("/accounts/:account/repos/:owner/:name/:resource?", async (c) => {
		const resource = c.req.param("resource") ?? "details";
		if (!REPO_SNAPSHOT_TABS.includes(resource as (typeof REPO_SNAPSHOT_TABS)[number]))
			throw new ApiError(404, "not_found", "unknown source");
		assertMachineQuery(c.req.query());
		const p = c.get("principal");
		return timedJson(
			c,
			await readMachineRepositoryObservation(
				c.get("db"),
				p.accountId,
				`${c.req.param("owner")}/${c.req.param("name")}`,
				resource,
			),
		);
	});
	app.get("/accounts/:account/:resource", async (c) => {
		const kind = c.req.param("resource");
		if (!["repos", "issues", "prs", "ci", "factory"].includes(kind))
			throw new ApiError(404, "not_found", "unknown source");
		const includeRemoved = kind === "repos" ? catalogInclude(c.req.queries()) : false;
		if (kind !== "repos") assertMachineQuery(c.req.query(), ["scope"]);
		const observation = await readMachineAccountObservation(
			c.get("db"),
			c.get("principal").accountId,
			kind as AccountObservationResource,
			snapshotScope(c.req.queries("scope")),
			includeRemoved,
		);
		if (kind === "repos") {
			observation.data = await enrichRepoAgentStates(
				c.get("db"),
				c.get("principal").accountId,
				observation.data,
			);
			observation.data = await enrichRepoMeta(
				c.get("db"),
				c.get("principal").accountId,
				observation.data,
			);
		}
		return timedJson(c, observation);
	});
	app.notFound(() => {
		throw new ApiError(404, "not_found", "unknown machine endpoint");
	});
	return app;
}
