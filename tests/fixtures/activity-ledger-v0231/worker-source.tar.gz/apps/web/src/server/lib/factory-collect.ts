import {
	factoryWindow,
	inWindow,
	mergeMetrics,
	summarizeEvents,
	uniqueEvents,
} from "../../lib/factory";
import { dependencyEvidence, dependencyFromEvent } from "../../lib/factory-dependencies";
import {
	FACTORY_STREAMS,
	type FactoryEvent,
	type FactoryRepo,
	type FactorySnapshot,
	type FactoryStreamData,
	type FactoryStreamName,
	type FactoryWindow,
} from "../../lib/factory-types";
import { ApiError } from "./errors";
import { collectContributions } from "./factory-contributions";
import {
	coverage,
	exclusion,
	mapDependencies,
	mapFactoryEvents,
	mapFactoryRepo,
	object,
	rows,
} from "./factory-map";
import { FACTORY_DEPENDENCIES_QUERY, FACTORY_INVENTORY_QUERY } from "./factory-queries";
import { assertFactoryReserve, recordFactoryRate } from "./factory-rate";
import type { GithubClient } from "./github-client";
import { githubUnavailability } from "./github-unavailable";
import { collectPrState } from "./pr-collect";

export const FACTORY_ITEM_CAP = 5000;
export const FACTORY_BYTE_CAP = 1_200_000;
export function newFactory(account: string, owner: string, now: string): FactorySnapshot {
	return {
		schema: 1,
		account_id: account,
		owner,
		runId: now,
		revision: 0,
		leaseUntil: null,
		startedAt: now,
		fetched_at: now,
		window: factoryWindow(now),
		status: "collecting",
		inventory: { total: 0, scanned: 0, complete: false, after: null, pages: 0, excluded: [] },
		repos: [],
		cursor: { repo: 0, stream: 0 },
		requests: 0,
		rate: null,
		contribution: null,
		contributionStatus: "pending",
	};
}
export function streamKey(repo: string, stream: FactoryStreamName): string {
	return `factory:${repo}:${stream}`;
}
export type FactoryStore = {
	baseline?: () => Promise<{
		data: FactoryStreamData;
		head: string | null;
		window: FactoryWindow;
	} | null>;
	read: (key: string) => Promise<FactoryStreamData | null>;
	write: (key: string, data: FactoryStreamData) => Promise<void>;
};

function updatedTime(item: FactoryEvent): number {
	return Date.parse(item.updatedAt ?? "");
}

function incrementalCursor(
	prior: Awaited<ReturnType<NonNullable<FactoryStore["baseline"]>>>,
	stream: "issues" | "prs",
	now: string,
): FactoryStreamData["incremental"] {
	if (
		prior?.data.coverage.status !== "complete" ||
		prior.data.coverage.retained ||
		prior.data.coverage.observation ||
		prior.data.next ||
		prior.data.ranges.length ||
		prior.data.coverage.observed !== prior.data.items.length ||
		new Set(prior.data.items.map((item) => item.id)).size !== prior.data.items.length ||
		prior.data.items.some((item) => !Number.isFinite(updatedTime(item)))
	)
		return;
	const fetchedAt = Date.parse(prior.data.coverage.fetchedAt ?? "");
	const startedAt = Date.parse(prior.window.until);
	const watermark = Math.min(fetchedAt, startedAt);
	const cutoff = new Date(watermark - 1000);
	if (
		!Number.isFinite(fetchedAt) ||
		!(fetchedAt < Date.parse(now)) ||
		!(startedAt <= Date.parse(now)) ||
		!Number.isFinite(cutoff.getTime())
	)
		return;
	return {
		since: cutoff.toISOString(),
		phase: "collect",
		pendingPrIds: stream === "prs" ? prior.data.items.map((item) => item.id) : [],
		observedIds: [],
	};
}

function resetIncremental(data: FactoryStreamData, first: string): void {
	data.items = [];
	data.next = first;
	data.coverage.source = first;
	data.coverage.strategy = "full";
	delete data.coverage.sourceFetchedAt;
	delete data.incremental;
}

function reconcileIncremental(
	data: FactoryStreamData,
	repo: FactoryRepo,
	stream: FactoryStreamName,
	first: string,
): void {
	if (!data.incremental || data.next) return;
	const counts =
		stream === "issues"
			? [repo.openIssues, repo.closedIssues]
			: [repo.openPrs, repo.closedPrs, repo.mergedPrs];
	const states = stream === "issues" ? ["open", "closed"] : ["open", "closed", "merged"];
	if (
		counts.some(
			(count, index) =>
				!Number.isSafeInteger(count) ||
				count < 0 ||
				data.items.filter((item) => item.state === states[index]).length !== count,
		) ||
		counts.reduce((total, count) => total + count, 0) !== data.items.length
	) {
		resetIncremental(data, first);
		return;
	}
	if (data.incremental.pendingPrIds.length) data.incremental.phase = "pr_state";
	else {
		data.items.sort((first, second) => updatedTime(second) - updatedTime(first));
		delete data.incremental;
	}
}

function source(repo: FactoryRepo, stream: FactoryStreamName, window: FactoryWindow): string {
	const base = `/repos/${repo.name}`;
	switch (stream) {
		case "commits":
			return `${base}/commits?sha=${repo.head}&since=${window.since}&until=${window.until}&per_page=100&page=1`;
		case "issues":
			return `${base}/issues?state=all&sort=updated&direction=desc&per_page=100&page=1`;
		case "prs":
			return `${base}/pulls?state=all&sort=updated&direction=desc&per_page=100&page=1`;
		case "actions":
			return `${base}/actions/runs?created=${window.since}..${window.until}&per_page=100&page=1`;
		case "releases":
			return `${base}/releases?per_page=100&page=1`;
		case "alerts":
			return `${base}/dependabot/alerts?state=open&per_page=100`;
		case "dependencies":
			return "https://api.github.com/graphql · pinned root manifests";
	}
}
/** Follow only GitHub pagination for the same resource. Never trust a foreign Link URL. */
export function factoryNext(link: string | null, current: string): string | null {
	const next = link?.match(/<([^>]+)>;\s*rel="next"/)?.[1];
	if (!next) return null;
	const url = new URL(next);
	const before = new URL(current, "https://api.github.com");
	const suffix = before.pathname.replace(/^\/repos\/[^/]+\/[^/]+/, "");
	const canonical = /^\/repositories\/\d+(\/.*)$/.exec(url.pathname)?.[1];
	if (
		url.origin !== "https://api.github.com" ||
		(url.pathname !== before.pathname && canonical !== suffix)
	)
		throw new ApiError(502, "github_error", "invalid pagination");
	// GitHub emits /repositories/:numericId links. Keep the requested named repository and
	// original filters; consume only pagination, never a new target or scope.
	if (suffix === "/dependabot/alerts") {
		const after = url.searchParams.get("after");
		if (!after || after === before.searchParams.get("after"))
			throw new ApiError(502, "github_error", "invalid pagination");
		before.searchParams.set("after", after);
	} else {
		const page = Number(url.searchParams.get("page"));
		const currentPage = Number(before.searchParams.get("page") ?? "1");
		if (!Number.isInteger(page) || page !== currentPage + 1)
			throw new ApiError(502, "github_error", "invalid pagination");
		before.searchParams.set("page", String(page));
	}
	return `${before.pathname}${before.search}`;
}
function rateFromData(s: FactorySnapshot, data: Record<string, unknown>, now: string) {
	const rate = object(data.rateLimit);
	if (typeof rate.remaining === "number")
		recordFactoryRate(s, {
			remaining: rate.remaining,
			resetAt: typeof rate.resetAt === "string" ? rate.resetAt : null,
			resource: "graphql",
			observedAt: now,
		});
}
async function inventory(s: FactorySnapshot, gh: GithubClient, token: string, now: string) {
	const data = await gh.githubGraphql(token, FACTORY_INVENTORY_QUERY, { after: s.inventory.after });
	rateFromData(s, data, now);
	const viewer = object(data.viewer);
	const conn = object(viewer.repositories);
	const info = object(conn.pageInfo);
	if (
		gh.graphqlErrors.length ||
		!Array.isArray(conn.nodes) ||
		String(viewer.login).toLowerCase() !== s.owner.toLowerCase()
	)
		throw new ApiError(502, "github_error", "inventory incomplete");
	for (const r of rows(conn.nodes)) {
		const reason = exclusion(r, s.owner);
		const name = String(r.nameWithOwner);
		if (reason) {
			if (!s.inventory.excluded.some((e) => e.name === name))
				s.inventory.excluded.push({ name, reason });
		} else if (!s.repos.some((repo) => repo.id === r.id))
			s.repos.push({ ...mapFactoryRepo(r), metadataAt: now });
	}
	s.inventory.total = Number(conn.totalCount);
	s.inventory.scanned = s.repos.length + s.inventory.excluded.length;
	s.inventory.pages++;
	if (
		info.hasNextPage &&
		(typeof info.endCursor !== "string" || info.endCursor === s.inventory.after)
	)
		throw new ApiError(502, "github_error", "invalid inventory cursor");
	s.inventory.after = info.hasNextPage ? String(info.endCursor) : null;
	s.inventory.complete = !info.hasNextPage;
	if (s.inventory.complete && s.inventory.scanned !== s.inventory.total)
		throw new ApiError(502, "github_error", "inventory changed; restart required");
}
function advanceCursor(s: FactorySnapshot) {
	s.cursor.stream++;
	if (s.cursor.stream >= FACTORY_STREAMS.length) {
		s.cursor.stream = 0;
		s.cursor.repo++;
	}
}
export function splitActionWindow(window: FactoryWindow): [FactoryWindow, FactoryWindow] | null {
	const start = Date.parse(window.since);
	const end = Date.parse(window.until);
	const mid = Math.floor((start + end) / 2);
	if (end - start <= 1000) return null;
	return [
		{ since: window.since, until: new Date(mid).toISOString() },
		{ since: new Date(mid).toISOString(), until: window.until },
	];
}
async function collectStream(
	s: FactorySnapshot,
	gh: GithubClient,
	token: string,
	store: FactoryStore,
	now: string,
) {
	const repo = s.repos[s.cursor.repo];
	const stream = FACTORY_STREAMS[s.cursor.stream];
	if (!repo || !stream) {
		s.status = "complete";
		return;
	}
	const key = streamKey(repo.name, stream);
	const first = source(repo, stream, s.window);
	const saved = repo.coverage[stream].status === "pending" ? null : await store.read(key);
	if (saved && saved.runId !== s.runId)
		throw new ApiError(409, "snapshot_missing", "resource belongs to another survey");
	const data: FactoryStreamData = saved ?? {
		runId: s.runId,
		items: [],
		next: first,
		ranges: [],
		coverage: coverage(first),
	};
	const prior =
		stream === "commits" ||
		stream === "dependencies" ||
		(!saved && (stream === "issues" || stream === "prs"))
			? await store.baseline?.()
			: null;
	const baseline =
		prior?.data.coverage.status === "complete" &&
		prior.window.since <= s.window.since &&
		prior.window.until <= s.window.until
			? prior
			: null;
	const retained =
		baseline?.data.items.filter(
			(e) =>
				stream !== "commits" ||
				inWindow(e.at, s.window) ||
				(Boolean(s.activityWindow) && Date.parse(e.at ?? "") === Date.parse(s.window.until)),
		) ?? [];
	if (!saved && prior && (stream === "issues" || stream === "prs")) {
		const incremental = incrementalCursor(prior, stream, now);
		if (incremental) {
			data.incremental = incremental;
			data.items = structuredClone(prior.data.items);
			data.coverage.sourceFetchedAt = prior.data.coverage.fetchedAt;
			data.next = stream === "issues" ? `${first}&since=${incremental.since}` : first;
			data.coverage.source = data.next;
		}
	}
	data.coverage.strategy = data.incremental ? "incremental" : "full";
	data.coverage.status = "partial";
	data.coverage.fetchedAt = now;
	try {
		if (data.incremental?.phase === "pr_state") {
			const pending = new Set(data.incremental.pendingPrIds.slice(0, 100));
			let refreshed = false;
			const page = await collectPrState(
				s,
				{
					...gh,
					get graphqlErrors() {
						return gh.graphqlErrors;
					},
					async githubGraphql(...args) {
						const result = await gh.githubGraphql(...args);
						const ids = new Set(rows(result.nodes).map((node) => node.id));
						refreshed = !gh.graphqlErrors.length && [...pending].every((id) => ids.has(id));
						return result;
					},
				},
				token,
				data.items.filter((item) => pending.has(item.id)),
				now,
			);
			if (refreshed) {
				data.items = uniqueEvents([...data.items, ...page]);
				data.incremental.pendingPrIds = data.incremental.pendingPrIds.slice(100);
			} else resetIncremental(data, first);
		} else if (
			baseline &&
			baseline.head === repo.head &&
			(stream === "dependencies" || stream === "commits")
		) {
			data.items = retained;
			data.next = null;
			data.coverage.strategy = "reused";
			data.coverage.sourceFetchedAt =
				baseline.data.coverage.sourceFetchedAt ?? baseline.data.coverage.fetchedAt;
			if (stream === "dependencies") data.manifests = baseline.data.manifests ?? [];
		} else if (stream === "dependencies" && !repo.head) {
			data.next = null;
		} else if (stream === "dependencies") {
			const [owner, name] = repo.name.split("/");
			const variables: Record<string, unknown> = { owner, name };
			for (const [alias, path] of [
				["package", "package.json"],
				["ci", ".github/workflows/ci.yml"],
				["release", ".github/workflows/release.yml"],
				["dependabot", ".github/dependabot.yml"],
				["renovate", "renovate.json"],
			])
				variables[String(alias)] = `${repo.head}:${path}`;
			const result = await gh.githubGraphql(token, FACTORY_DEPENDENCIES_QUERY, variables);
			rateFromData(s, result, now);
			if (gh.graphqlErrors.length)
				throw new ApiError(403, "github_forbidden", "manifest unavailable");
			if (!result.repository || typeof result.repository !== "object")
				throw new ApiError(502, "github_error", "manifest response incomplete");
			try {
				Object.assign(data, mapDependencies(object(result.repository), repo));
			} catch {
				data.coverage.status = "limited";
				data.coverage.reason_code = "dependency_parse_unsupported";
				data.coverage.reason = "Dependency manifests cannot be parsed safely; evidence unavailable";
			}
			data.next = null;
		} else if (stream === "commits" && !repo.head) {
			data.next = null;
		} else {
			const path = data.next ?? first;
			const response = await gh.githubApi(token, path);
			const remaining = response.headers.get("x-ratelimit-remaining");
			const reset = response.headers.get("x-ratelimit-reset");
			if (remaining !== null)
				recordFactoryRate(s, {
					remaining: Number(remaining),
					resetAt: reset ? new Date(Number(reset) * 1000).toISOString() : null,
					resource: "core",
					observedAt: now,
				});
			const payload: unknown = await response.json();
			if (stream === "actions" && Number(object(payload).total_count) > 1000) {
				const range = new URL(path, "https://api.github.com").searchParams
					.get("created")
					?.split("..");
				const parts = splitActionWindow({
					since: range?.[0] ?? s.window.since,
					until: range?.[1] ?? s.window.until,
				});
				if (!parts) {
					data.coverage.status = "limited";
					data.coverage.reason = "More than 1,000 workflow runs in one second";
					data.next = null;
				} else {
					data.ranges.unshift(...parts);
					data.next = null;
				}
			} else {
				const list = stream === "actions" ? object(payload).workflow_runs : payload;
				if (!Array.isArray(list)) throw new ApiError(502, "github_error", "invalid resource list");
				let page = mapFactoryEvents(stream, rows(list)).filter(
					(e) =>
						(stream !== "commits" && stream !== "actions") ||
						inWindow(e.at, s.window) ||
						(Boolean(s.activityWindow) && Date.parse(e.at ?? "") === Date.parse(s.window.until)),
				);
				if (stream === "prs") page = await collectPrState(s, gh, token, page, now);
				if (data.incremental && page.some((item) => !Number.isFinite(updatedTime(item)))) {
					resetIncremental(data, first);
				} else {
					data.items = uniqueEvents([...data.items, ...page]);
					data.next = factoryNext(response.headers.get("link"), path);
					if (data.incremental) {
						const since = Date.parse(data.incremental.since);
						const seen = new Set([...data.incremental.observedIds, ...page.map((item) => item.id)]);
						data.incremental.observedIds = [...seen];
						data.incremental.pendingPrIds = data.incremental.pendingPrIds.filter(
							(id) => !seen.has(id),
						);
						if (stream === "prs" && !data.next && seen.size !== data.items.length) {
							resetIncremental(data, first);
						} else if (stream === "prs" && page.some((item) => updatedTime(item) < since)) {
							data.next = null;
						}
					}
				}
				const ids = new Set(retained.map((e) => e.id));
				if (stream === "commits" && data.next && page.some((e) => ids.has(e.id))) {
					data.items = uniqueEvents([...retained, ...data.items]);
					data.next = null;
					data.ranges = [];
					data.coverage.strategy = "incremental";
					data.coverage.sourceFetchedAt =
						baseline?.data.coverage.sourceFetchedAt ?? baseline?.data.coverage.fetchedAt ?? null;
				}
			}
		}
		reconcileIncremental(data, repo, stream, first);
		if (data.coverage.strategy !== "reused") data.coverage.pages++;
		if (stream === "actions" && data.coverage.pages >= 100 && (data.next || data.ranges.length)) {
			data.coverage.status = "limited";
			data.coverage.reason = "Workflow pagination exceeds 100-page budget; observed subset only";
			data.next = null;
			data.ranges = [];
		}
		if (!data.next && data.ranges.length && data.coverage.status !== "limited") {
			const range = data.ranges.shift();
			if (range)
				data.next = `/repos/${repo.name}/actions/runs?created=${range.since}..${range.until}&per_page=100&page=1`;
		}
		if (
			data.items.length > FACTORY_ITEM_CAP ||
			new TextEncoder().encode(JSON.stringify(data)).length > FACTORY_BYTE_CAP
		) {
			data.items = data.items.slice(0, FACTORY_ITEM_CAP);
			while (new TextEncoder().encode(JSON.stringify(data)).length > FACTORY_BYTE_CAP) {
				if (!data.items.length)
					throw new ApiError(
						422,
						"factory_capacity",
						"resource metadata exceeds capacity; previous data retained",
					);
				data.items = data.items.slice(0, Math.floor(data.items.length * 0.9));
			}
			data.coverage.status = "limited";
			data.coverage.reason = "Resource exceeds 5,000 records or 1.2 MB; observed subset only";
			data.next = null;
			data.ranges = [];
		}
		if (!data.next && !data.incremental && data.coverage.status === "partial")
			data.coverage.status = "complete";
	} catch (error) {
		if (
			error instanceof ApiError &&
			(error.code === "github_forbidden" ||
				error.code === "not_found" ||
				error.code === "github_response_too_large")
		) {
			data.coverage.status =
				data.items.length || data.coverage.pages > 0 || error.code === "github_response_too_large"
					? "limited"
					: "unavailable";
			const unavailable = githubUnavailability(error);
			if (unavailable) data.coverage.reason_code = unavailable.reason_code;
			data.coverage.reason =
				error.code === "github_response_too_large"
					? "GitHub response exceeds the 4 MB memory budget; evidence unavailable"
					: data.items.length
						? "GitHub access lost during pagination (403/404); incomplete observed subset only"
						: (unavailable?.reason ?? "GitHub resource unavailable");
			data.next = null;
			data.ranges = [];
		} else throw error;
	}
	if (stream === "dependencies")
		Object.assign(data, dependencyEvidence(data.items, data.manifests));
	data.coverage.observed = data.items.length;
	repo.coverage[stream] = data.coverage;
	if (data.coverage.status !== "partial") {
		repo.metrics = mergeMetrics([repo.metrics, summarizeEvents(stream, data.items, s.window)]);
		if (stream === "dependencies") {
			repo.dependencies = data.items.map(dependencyFromEvent);
			repo.manifests = data.manifests ?? [];
		}
		advanceCursor(s);
	}
	await store.write(key, data);
}
/** One bounded page. Completed streams are cached; a resumed job keeps its frozen window/head. */
export async function stepFactory(
	s: FactorySnapshot,
	gh: GithubClient,
	token: string,
	store: FactoryStore,
	now: string,
): Promise<void> {
	if (s.status === "complete" || s.status === "partial") return;
	assertFactoryReserve(s, now);
	const before = gh.count;
	try {
		if (!s.inventory.complete) await inventory(s, gh, token, now);
		else if (s.contributionStatus === "pending") await collectContributions(s, gh, token, now);
		else await collectStream(s, gh, token, store, now);
		s.fetched_at = now;
		s.revision++;
	} finally {
		s.requests += gh.count - before;
	}
}
